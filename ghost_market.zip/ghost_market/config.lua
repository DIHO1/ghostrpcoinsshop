Config = {}

-- Framework & Command Configuration
Config.Framework = 'ESX' -- Framework (ESX is supported)
Config.OpenCommand = 'market' -- Command to open the Ghost Market

-- Premium Currency Configuration
Config.Currency = {
    name = 'Ghost Coins',
    symbol = '💎',
    color = '#00FFFF' -- Neon/Cyberpunk color for the currency symbol
}

-- Anti-Spam Logic
Config.EnableAntiSpam = true -- Set to true to prevent purchase spamming
Config.AntiSpamDelay = 2000 -- Cooldown in milliseconds (2 seconds)

-- Shop Items Definition
Config.ShopItems = {
    {
        label = 'Zestaw Medyczny',
        price = 50,
        icon = '💊',
        description = 'Pakiet 5 apteczek, aby szybko wrócić do zdrowia.',
        rewardData = {
            type = 'item',
            name = 'medkit',
            amount = 5
        }
    },
    {
        label = 'Dotacja Gotówkowa',
        price = 100,
        icon = '💰',
        description = 'Natychmiastowy zastrzyk 25,000$ czystej gotówki na Twoje konto.',
        rewardData = {
            type = 'money',
            account = 'money', -- 'money', 'black_money', 'bank'
            amount = 25000
        }
    },
    {
        label = 'Status VIP',
        price = 500,
        icon = '👑',
        description = 'Nadaje permanentny status VIP, odblokowując specjalne korzyści.',
        rewardData = {
            type = 'group',
            name = 'vip' -- The name of the group/permission to grant
        }
    },
    {
        label = 'Super Samochód',
        price = 1200,
        icon = '🏎️',
        description = 'Odbierz kluczyki do legendarnego Pegassi Zentorno.',
        rewardData = {
            type = 'vehicle',
            model = 'zentorno',
            plate = 'GHOST' -- Optional: set a custom plate
        }
    },
    {
        label = 'Tajemnicza Skrzynia',
        price = 250,
        icon = '📦',
        description = 'Zawiera losowy, rzadki przedmiot. Co znajdziesz w środku?',
        rewardData = {
            type = 'item',
            name = 'mystery_box',
            amount = 1
        }
    }
}
